﻿
using (var game = new sprint0.Game1())
game.Run();
